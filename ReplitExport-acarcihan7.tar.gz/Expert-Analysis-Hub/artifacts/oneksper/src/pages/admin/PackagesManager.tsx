import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useListPackages, getListPackagesQueryKey, useAdminCreatePackage, useAdminUpdatePackage, useAdminDeletePackage } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, Edit, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const packageSchema = z.object({
  name: z.string().min(1, "Paket adı gerekli"),
  description: z.string().min(1, "Açıklama gerekli"),
  priceKurus: z.coerce.number().min(0),
  featuresText: z.string().min(1, "En az 1 özellik gerekli (her satıra bir tane)"),
  isPopular: z.boolean().default(false),
  isActive: z.boolean().default(true),
  sortOrder: z.coerce.number().default(0),
});

export default function AdminPackagesManager() {
  const queryClient = useQueryClient();
  const [editingPkg, setEditingPkg] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: packages, isLoading } = useListPackages({
    query: { queryKey: getListPackagesQueryKey() }
  });

  const createPackage = useAdminCreatePackage();
  const updatePackage = useAdminUpdatePackage();
  const deletePackage = useAdminDeletePackage();

  const form = useForm<z.infer<typeof packageSchema>>({
    resolver: zodResolver(packageSchema),
    defaultValues: {
      name: "",
      description: "",
      priceKurus: 0,
      featuresText: "",
      isPopular: false,
      isActive: true,
      sortOrder: 0,
    }
  });

  const openNewForm = () => {
    setEditingPkg(null);
    form.reset({
      name: "",
      description: "",
      priceKurus: 0,
      featuresText: "",
      isPopular: false,
      isActive: true,
      sortOrder: 0,
    });
    setIsDialogOpen(true);
  };

  const openEditForm = (pkg: any) => {
    setEditingPkg(pkg);
    form.reset({
      name: pkg.name,
      description: pkg.description,
      priceKurus: pkg.priceKurus,
      featuresText: pkg.features.join('\n'),
      isPopular: pkg.isPopular,
      isActive: pkg.isActive,
      sortOrder: pkg.sortOrder,
    });
    setIsDialogOpen(true);
  };

  const onSubmit = (values: z.infer<typeof packageSchema>) => {
    const features = values.featuresText.split('\n').map(s => s.trim()).filter(Boolean);
    const data = {
      name: values.name,
      description: values.description,
      priceKurus: values.priceKurus,
      features,
      isPopular: values.isPopular,
      isActive: values.isActive,
      sortOrder: values.sortOrder,
    };

    if (editingPkg) {
      updatePackage.mutate({ id: editingPkg.id, data }, {
        onSuccess: () => {
          toast.success("Paket güncellendi.");
          queryClient.invalidateQueries({ queryKey: getListPackagesQueryKey() });
          setIsDialogOpen(false);
        },
        onError: () => toast.error("Paket güncellenirken hata oluştu.")
      });
    } else {
      createPackage.mutate({ data }, {
        onSuccess: () => {
          toast.success("Paket oluşturuldu.");
          queryClient.invalidateQueries({ queryKey: getListPackagesQueryKey() });
          setIsDialogOpen(false);
        },
        onError: () => toast.error("Paket oluşturulurken hata oluştu.")
      });
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Bu paketi silmek istediğinize emin misiniz?")) {
      deletePackage.mutate({ id }, {
        onSuccess: () => {
          toast.success("Paket silindi.");
          queryClient.invalidateQueries({ queryKey: getListPackagesQueryKey() });
        },
        onError: () => toast.error("Paket silinirken hata oluştu.")
      });
    }
  };

  return (
    <AppLayout requireAdmin>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Paket Yönetimi</h1>
          <p className="text-muted-foreground mt-1">Sistemdeki fiyatlandırma ve analiz paketlerini yönetin.</p>
        </div>
        <Button onClick={openNewForm} className="gap-2">
          <Plus className="h-4 w-4" /> Yeni Paket
        </Button>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px] bg-card border-border/50">
          <DialogHeader>
            <DialogTitle>{editingPkg ? 'Paketi Düzenle' : 'Yeni Paket Oluştur'}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem><FormLabel>Paket Adı</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="priceKurus" render={({ field }) => (
                  <FormItem><FormLabel>Fiyat (Kuruş - Örn: 100 TL = 10000)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem><FormLabel>Kısa Açıklama</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="featuresText" render={({ field }) => (
                <FormItem><FormLabel>Özellikler (Her satıra bir tane)</FormLabel><FormControl><Textarea {...field} rows={6} /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-3 gap-4 pt-2">
                <FormField control={form.control} name="sortOrder" render={({ field }) => (
                  <FormItem><FormLabel>Sıra (Sort Order)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="isPopular" render={({ field }) => (
                  <FormItem className="flex flex-row items-end space-x-3 space-y-0 p-4 border rounded-md">
                    <FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    <FormLabel className="font-normal cursor-pointer">Popüler (Vurgula)</FormLabel>
                  </FormItem>
                )} />
                <FormField control={form.control} name="isActive" render={({ field }) => (
                  <FormItem className="flex flex-row items-end space-x-3 space-y-0 p-4 border rounded-md">
                    <FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                    <FormLabel className="font-normal cursor-pointer">Aktif Göster</FormLabel>
                  </FormItem>
                )} />
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>İptal</Button>
                <Button type="submit" disabled={createPackage.isPending || updatePackage.isPending}>
                  {(createPackage.isPending || updatePackage.isPending) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Kaydet
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {isLoading ? (
        <div className="grid md:grid-cols-3 gap-6">
          {[1,2,3].map(i => <Card key={i} className="animate-pulse h-[300px]"></Card>)}
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-6">
          {packages?.map(pkg => (
            <Card key={pkg.id} className={`bg-card flex flex-col ${pkg.isActive ? 'border-border/50' : 'border-dashed border-muted-foreground/30 opacity-70'}`}>
              <CardHeader className="pb-4 border-b border-border/50">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl flex items-center gap-2">
                      {pkg.name}
                      {pkg.isPopular && <Badge variant="default" className="text-[10px] uppercase">Popüler</Badge>}
                      {!pkg.isActive && <Badge variant="secondary" className="text-[10px] uppercase">Pasif</Badge>}
                    </CardTitle>
                    <CardDescription className="mt-1">{pkg.description}</CardDescription>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-bold font-mono text-primary">₺{(pkg.priceKurus/100).toLocaleString('tr-TR')}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4 flex-1">
                <ul className="space-y-2 text-sm text-muted-foreground">
                  {pkg.features.map((f, i) => (
                    <li key={i} className="flex items-start before:content-['—'] before:mr-2 before:text-border">{f}</li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="border-t border-border/50 pt-4 flex gap-2">
                <Button variant="outline" className="flex-1 gap-2" onClick={() => openEditForm(pkg)}>
                  <Edit className="h-4 w-4" /> Düzenle
                </Button>
                <Button variant="destructive" size="icon" onClick={() => handleDelete(pkg.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </AppLayout>
  );
}
