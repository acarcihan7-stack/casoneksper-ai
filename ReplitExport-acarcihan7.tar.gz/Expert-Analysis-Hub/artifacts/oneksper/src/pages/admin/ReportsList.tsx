import { useAdminListReports, getAdminListReportsQueryKey } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Loader2, ExternalLink, Download } from "lucide-react";
import { Link } from "wouter";

export default function AdminReportsList() {
  const { data: reports, isLoading } = useAdminListReports({
    query: { queryKey: getAdminListReportsQueryKey() }
  });

  return (
    <AppLayout requireAdmin>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Raporlar</h1>
          <p className="text-muted-foreground mt-1">Sistemdeki tüm teslim edilmiş analiz raporları.</p>
        </div>
      </div>

      <div className="border border-border/50 rounded-xl overflow-hidden bg-card shadow-sm">
        <div className="overflow-x-auto relative min-h-[400px]">
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center bg-card/50 z-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : null}
          
          <table className="w-full text-sm text-left">
            <thead className="bg-muted/50 text-muted-foreground uppercase text-xs">
              <tr>
                <th className="px-6 py-3 font-medium">ID</th>
                <th className="px-6 py-3 font-medium">Analiz ID</th>
                <th className="px-6 py-3 font-medium">Risk Skoru</th>
                <th className="px-6 py-3 font-medium">Oluşturulma</th>
                <th className="px-6 py-3 font-medium text-right">İşlem</th>
              </tr>
            </thead>
            <tbody>
              {reports?.map((report) => (
                <tr key={report.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-muted-foreground">#{report.id}</td>
                  <td className="px-6 py-4">
                    <Link href={`/admin/analyses/${report.analysisId}`} className="text-primary hover:underline font-mono">
                      Analiz #{report.analysisId}
                    </Link>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-full bg-secondary rounded-full h-2 max-w-[100px]">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${report.riskScore || 0}%`, backgroundColor: (report.riskScore || 0) > 70 ? 'hsl(var(--destructive))' : (report.riskScore || 0) > 40 ? 'hsl(var(--accent))' : 'hsl(var(--primary))' }}
                        ></div>
                      </div>
                      <span className="font-mono text-xs">{report.riskScore || 0}/100</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-mono text-xs">
                    {new Date(report.createdAt).toLocaleDateString('tr-TR')}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <a href={report.reportUrl} target="_blank" rel="noreferrer">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0" title="Raporu Gör">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </a>
                    </div>
                  </td>
                </tr>
              ))}
              {(!reports || reports.length === 0) && !isLoading && (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">Rapor bulunamadı.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppLayout>
  );
}
