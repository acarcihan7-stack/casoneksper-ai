import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { analysesTable } from "./analyses";

export const reportsTable = pgTable("reports", {
  id: serial("id").primaryKey(),
  analysisId: integer("analysis_id").notNull().unique().references(() => analysesTable.id),
  reportUrl: text("report_url").notNull(),
  summary: text("summary"),
  riskScore: integer("risk_score"), // 0-100
  findings: text("findings"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertReportSchema = createInsertSchema(reportsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reportsTable.$inferSelect;
