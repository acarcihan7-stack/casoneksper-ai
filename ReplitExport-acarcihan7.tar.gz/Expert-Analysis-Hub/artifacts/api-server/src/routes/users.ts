import { Router, type IRouter } from "express";
import { eq, count } from "drizzle-orm";
import { db, usersTable, analysesTable } from "@workspace/db";
import { requireAuth, getOrCreateUser } from "../lib/auth";
import {
  GetMeResponse,
  UpdateMeBody,
  UpdateMeResponse,
} from "@workspace/api-zod";
import { getAuth } from "@clerk/express";

const router: IRouter = Router();

// GET /users/me
router.get("/users/me", requireAuth, async (req, res): Promise<void> => {
  const clerkId = (req as any).clerkId as string;
  const auth = getAuth(req);
  const email = auth?.sessionClaims?.email as string ?? "";
  const name = auth?.sessionClaims?.name as string | undefined;

  const user = await getOrCreateUser(clerkId, email, name);

  const [countResult] = await db
    .select({ count: count() })
    .from(analysesTable)
    .where(eq(analysesTable.userId, user.id));

  const result = {
    ...user,
    analysisCount: Number(countResult?.count ?? 0),
  };

  res.json(GetMeResponse.parse(result));
});

// PUT /users/me
router.put("/users/me", requireAuth, async (req, res): Promise<void> => {
  const clerkId = (req as any).clerkId as string;
  const parsed = UpdateMeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const auth = getAuth(req);
  const email = auth?.sessionClaims?.email as string ?? "";

  const [existing] = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId));
  if (!existing) {
    await getOrCreateUser(clerkId, email);
  }

  const [updated] = await db
    .update(usersTable)
    .set(parsed.data)
    .where(eq(usersTable.clerkId, clerkId))
    .returning();

  const [countResult] = await db
    .select({ count: count() })
    .from(analysesTable)
    .where(eq(analysesTable.userId, updated.id));

  res.json(UpdateMeResponse.parse({ ...updated, analysisCount: Number(countResult?.count ?? 0) }));
});

export default router;
