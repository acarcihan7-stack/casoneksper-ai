export const statusMap: Record<string, { label: string, variant: 'default'|'secondary'|'destructive'|'outline', colorClass: string }> = {
  pending: { label: "Beklemede", variant: "secondary", colorClass: "bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20 border-yellow-500/20" },
  paid: { label: "Ödendi", variant: "outline", colorClass: "bg-blue-500/10 text-blue-500 hover:bg-blue-500/20 border-blue-500/20" },
  processing: { label: "İşleniyor", variant: "outline", colorClass: "bg-purple-500/10 text-purple-500 hover:bg-purple-500/20 border-purple-500/20" },
  completed: { label: "Tamamlandı", variant: "default", colorClass: "bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 border-emerald-500/20" },
  cancelled: { label: "İptal", variant: "destructive", colorClass: "bg-red-500/10 text-red-500 hover:bg-red-500/20 border-red-500/20" },
};

export const paymentStatusMap: Record<string, { label: string, colorClass: string }> = {
  unpaid: { label: "Ödenmedi", colorClass: "text-muted-foreground" },
  paid: { label: "Ödendi", colorClass: "text-emerald-500" },
  refunded: { label: "İade Edildi", colorClass: "text-yellow-500" },
};
