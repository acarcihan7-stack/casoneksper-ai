import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, usersTable, analysesTable, packagesTable, reportsTable } from "@workspace/db";
import { requireAuth, getOrCreateUser } from "../lib/auth";
import {
  ListMyAnalysesResponse,
  CreateAnalysisBody,
  CreateAnalysisResponse,
  GetAnalysisParams,
  GetAnalysisResponse,
  InitiatePaymentParams,
  InitiatePaymentBody,
  InitiatePaymentResponse,
  GetMyReportParams,
  GetMyReportResponse,
} from "@workspace/api-zod";
import { getAuth } from "@clerk/express";

const router: IRouter = Router();

// GET /analyses
router.get("/analyses", requireAuth, async (req, res): Promise<void> => {
  const clerkId = (req as any).clerkId as string;
  const auth = getAuth(req);
  const email = auth?.sessionClaims?.email as string ?? "";
  const user = await getOrCreateUser(clerkId, email);

  const analyses = await db
    .select({
      id: analysesTable.id,
      userId: analysesTable.userId,
      listingUrl: analysesTable.listingUrl,
      vehicleBrand: analysesTable.vehicleBrand,
      vehicleModel: analysesTable.vehicleModel,
      vehicleYear: analysesTable.vehicleYear,
      plateNumber: analysesTable.plateNumber,
      notes: analysesTable.notes,
      status: analysesTable.status,
      packageId: analysesTable.packageId,
      packageName: packagesTable.name,
      paymentStatus: analysesTable.paymentStatus,
      reportId: reportsTable.id,
      createdAt: analysesTable.createdAt,
      updatedAt: analysesTable.updatedAt,
      userEmail: usersTable.email,
      userName: usersTable.name,
    })
    .from(analysesTable)
    .leftJoin(packagesTable, eq(analysesTable.packageId, packagesTable.id))
    .leftJoin(reportsTable, eq(reportsTable.analysisId, analysesTable.id))
    .leftJoin(usersTable, eq(analysesTable.userId, usersTable.id))
    .where(eq(analysesTable.userId, user.id))
    .orderBy(desc(analysesTable.createdAt));

  res.json(ListMyAnalysesResponse.parse(analyses));
});

// POST /analyses
router.post("/analyses", requireAuth, async (req, res): Promise<void> => {
  const clerkId = (req as any).clerkId as string;
  const auth = getAuth(req);
  const email = auth?.sessionClaims?.email as string ?? "";
  const user = await getOrCreateUser(clerkId, email);

  const parsed = CreateAnalysisBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const pkg = await db.select().from(packagesTable).where(eq(packagesTable.id, parsed.data.packageId));
  if (!pkg.length) {
    res.status(400).json({ error: "Invalid package" });
    return;
  }

  const [analysis] = await db
    .insert(analysesTable)
    .values({
      userId: user.id,
      listingUrl: parsed.data.listingUrl,
      vehicleBrand: parsed.data.vehicleBrand,
      vehicleModel: parsed.data.vehicleModel,
      vehicleYear: parsed.data.vehicleYear,
      plateNumber: parsed.data.plateNumber,
      notes: parsed.data.notes,
      packageId: parsed.data.packageId,
    })
    .returning();

  const result = {
    ...analysis,
    packageName: pkg[0].name,
    reportId: null,
    userEmail: email,
    userName: null,
  };

  res.status(201).json(CreateAnalysisResponse.parse(result));
});

// GET /analyses/:id
router.get("/analyses/:id", requireAuth, async (req, res): Promise<void> => {
  const clerkId = (req as any).clerkId as string;
  const auth = getAuth(req);
  const email = auth?.sessionClaims?.email as string ?? "";
  const user = await getOrCreateUser(clerkId, email);

  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetAnalysisParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [analysis] = await db
    .select({
      id: analysesTable.id,
      userId: analysesTable.userId,
      listingUrl: analysesTable.listingUrl,
      vehicleBrand: analysesTable.vehicleBrand,
      vehicleModel: analysesTable.vehicleModel,
      vehicleYear: analysesTable.vehicleYear,
      plateNumber: analysesTable.plateNumber,
      notes: analysesTable.notes,
      status: analysesTable.status,
      packageId: analysesTable.packageId,
      packageName: packagesTable.name,
      paymentStatus: analysesTable.paymentStatus,
      reportId: reportsTable.id,
      createdAt: analysesTable.createdAt,
      updatedAt: analysesTable.updatedAt,
      userEmail: usersTable.email,
      userName: usersTable.name,
    })
    .from(analysesTable)
    .leftJoin(packagesTable, eq(analysesTable.packageId, packagesTable.id))
    .leftJoin(reportsTable, eq(reportsTable.analysisId, analysesTable.id))
    .leftJoin(usersTable, eq(analysesTable.userId, usersTable.id))
    .where(and(eq(analysesTable.id, params.data.id), eq(analysesTable.userId, user.id)));

  if (!analysis) {
    res.status(404).json({ error: "Analysis not found" });
    return;
  }

  res.json(GetAnalysisResponse.parse(analysis));
});

// POST /analyses/:id/pay
router.post("/analyses/:id/pay", requireAuth, async (req, res): Promise<void> => {
  const clerkId = (req as any).clerkId as string;
  const auth = getAuth(req);
  const email = auth?.sessionClaims?.email as string ?? "";
  const user = await getOrCreateUser(clerkId, email);

  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = InitiatePaymentParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const bodyParsed = InitiatePaymentBody.safeParse(req.body);
  if (!bodyParsed.success) {
    res.status(400).json({ error: bodyParsed.error.message });
    return;
  }

  const [analysis] = await db
    .select()
    .from(analysesTable)
    .where(and(eq(analysesTable.id, params.data.id), eq(analysesTable.userId, user.id)));

  if (!analysis) {
    res.status(404).json({ error: "Analysis not found" });
    return;
  }

  if (analysis.paymentStatus === "paid") {
    res.json(InitiatePaymentResponse.parse({
      analysisId: analysis.id,
      status: "already_paid",
      message: "Bu analiz zaten ödenmiş.",
      checkoutUrl: null,
    }));
    return;
  }

  // Simulate payment success (Stripe integration placeholder)
  await db
    .update(analysesTable)
    .set({ paymentStatus: "paid", status: "processing" })
    .where(eq(analysesTable.id, params.data.id));

  res.json(InitiatePaymentResponse.parse({
    analysisId: analysis.id,
    status: "success",
    message: "Ödeme alındı. Raporunuz hazırlanıyor.",
    checkoutUrl: null,
  }));
});

// GET /analyses/:id/report
router.get("/analyses/:id/report", requireAuth, async (req, res): Promise<void> => {
  const clerkId = (req as any).clerkId as string;
  const auth = getAuth(req);
  const email = auth?.sessionClaims?.email as string ?? "";
  const user = await getOrCreateUser(clerkId, email);

  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetMyReportParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [analysis] = await db
    .select()
    .from(analysesTable)
    .where(and(eq(analysesTable.id, params.data.id), eq(analysesTable.userId, user.id)));

  if (!analysis) {
    res.status(404).json({ error: "Analysis not found" });
    return;
  }

  if (analysis.paymentStatus !== "paid") {
    res.status(403).json({ error: "Raporu görmek için ödeme gereklidir." });
    return;
  }

  const [report] = await db
    .select()
    .from(reportsTable)
    .where(eq(reportsTable.analysisId, params.data.id));

  if (!report) {
    res.status(404).json({ error: "Rapor henüz hazır değil." });
    return;
  }

  res.json(GetMyReportResponse.parse(report));
});

export default router;
