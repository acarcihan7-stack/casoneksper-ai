import { useEffect } from "react";
import { useLocation } from "wouter";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@clerk/react";
import { Loader2 } from "lucide-react";

export default function DashboardRedirect() {
  const [, setLocation] = useLocation();
  const { isSignedIn } = useAuth();
  
  const { data: user, isLoading } = useGetMe({
    query: {
      enabled: !!isSignedIn,
      queryKey: getGetMeQueryKey()
    }
  });

  useEffect(() => {
    if (!isLoading && user) {
      if (user.role === 'admin') {
        setLocation('/admin');
      } else {
        setLocation('/dashboard');
      }
    }
  }, [user, isLoading, setLocation]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );
}
