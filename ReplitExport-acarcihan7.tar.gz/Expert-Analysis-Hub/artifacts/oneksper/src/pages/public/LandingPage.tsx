import { Link } from "wouter";
import { useListPackages, getListPackagesQueryKey } from "@workspace/api-client-react";
import { ShieldCheck, Zap, BarChart3, ChevronRight } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function LandingPage() {
  const { data: packages, isLoading } = useListPackages({
    query: {
      queryKey: getListPackagesQueryKey()
    }
  });

  return (
    <div className="min-h-screen bg-background selection:bg-primary/30">
      {/* Navbar */}
      <nav className="border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={`${import.meta.env.BASE_URL.replace(/\/$/, "") || ""}/logo.svg`} alt="OnEksper AI" className="h-8 w-auto" />
          </div>
          <div className="flex items-center gap-4">
            <Link href="/sign-in" className={buttonVariants({ variant: "ghost", className: "hidden sm:inline-flex" })}>
              Giriş Yap
            </Link>
            <Link href="/sign-up" className={buttonVariants()}>
              Ücretsiz Başla
            </Link>
          </div>
        </div>
      </nav>

      <main>
        {/* Hero Section */}
        <section className="relative pt-24 pb-32 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background pointer-events-none"></div>
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <Badge variant="outline" className="mb-6 border-primary/30 text-primary bg-primary/10 px-4 py-1.5 text-sm">
              Yapay Zeka Destekli Araç Analizi
            </Badge>
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-display font-bold tracking-tight text-foreground mb-8 leading-tight">
              Görünmeyen Riskleri <br className="hidden sm:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">Satın Almadan Önce</span> Görün.
            </h1>
            <p className="max-w-2xl mx-auto text-lg sm:text-xl text-muted-foreground mb-10">
              Araç ilan linkini yapıştırın, yapay zeka saniyeler içinde gizli hasar kayıtlarını, fiyat tutarsızlıklarını ve risk faktörlerini raporlasın.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/sign-up" className={buttonVariants({ size: "lg", className: "w-full sm:w-auto text-base h-14 px-8 font-medium" })}>
                Hemen Sorgula <ChevronRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-24 bg-card/30 border-y border-border/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-display font-bold mb-4">Nasıl Çalışır?</h2>
              <p className="text-muted-foreground">3 basit adımda tam kapsamlı araç istihbaratı</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: Zap,
                  title: "1. İlanı Yapıştırın",
                  description: "İlgilendiğiniz aracın ilan linkini sisteme girin. Marka, model ve yıl bilgilerini onaylayın."
                },
                {
                  icon: BarChart3,
                  title: "2. Yapay Zeka Analizi",
                  description: "Sistemimiz binlerce veri noktasını tarar, emsal fiyatları karşılaştırır ve olası riskleri tespit eder."
                },
                {
                  icon: ShieldCheck,
                  title: "3. Raporu İndirin",
                  description: "Kapsamlı risk skorunuzu ve detaylı ön ekspertiz raporunuzu PDF olarak anında görüntüleyin."
                }
              ].map((feature, i) => (
                <div key={i} className="relative p-6 bg-background rounded-2xl border border-border/50 shadow-sm hover:border-primary/30 transition-colors">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section className="py-24" id="pricing">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-display font-bold mb-4">Analiz Paketleri</h2>
              <p className="text-muted-foreground">İhtiyacınıza uygun raporlama seviyesini seçin</p>
            </div>

            {isLoading ? (
              <div className="grid md:grid-cols-3 gap-8">
                {[1, 2, 3].map(i => (
                  <Card key={i} className="animate-pulse h-[400px] bg-card border-border/50"></Card>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-3 gap-8">
                {packages?.map((pkg) => (
                  <Card key={pkg.id} className={`relative bg-card flex flex-col ${pkg.isPopular ? 'border-primary shadow-primary/20 shadow-xl' : 'border-border/50'}`}>
                    {pkg.isPopular && (
                      <div className="absolute -top-3 left-0 right-0 flex justify-center">
                        <span className="bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                          EN ÇOK TERCİH EDİLEN
                        </span>
                      </div>
                    )}
                    <CardHeader>
                      <CardTitle className="text-2xl">{pkg.name}</CardTitle>
                      <CardDescription>{pkg.description}</CardDescription>
                      <div className="mt-4">
                        <span className="text-4xl font-bold text-foreground">₺{(pkg.priceKurus / 100).toLocaleString('tr-TR')}</span>
                        <span className="text-muted-foreground"> / rapor</span>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-1">
                      <ul className="space-y-3">
                        {pkg.features.map((feature, i) => (
                          <li key={i} className="flex items-start">
                            <ShieldCheck className="h-5 w-5 text-primary shrink-0 mr-3" />
                            <span className="text-muted-foreground">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Link href="/sign-up" className="w-full">
                        <Button className="w-full" variant={pkg.isPopular ? "default" : "outline"}>
                          Seç
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-card py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-muted-foreground">
          <p>© {new Date().getFullYear()} OnEksper AI. Tüm hakları saklıdır.</p>
        </div>
      </footer>
    </div>
  );
}
