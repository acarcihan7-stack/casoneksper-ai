import { useRoute } from "wouter";
import { useAdminGetUser, getAdminGetUserQueryKey, useAdminUpdateUser, getAdminListUsersQueryKey } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ShieldAlert, UserX, UserCheck } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export default function AdminUserDetail() {
  const [, params] = useRoute("/admin/users/:id");
  const id = params?.id ? parseInt(params.id, 10) : 0;
  const queryClient = useQueryClient();

  const { data: user, isLoading } = useAdminGetUser(id, {
    query: { enabled: !!id, queryKey: getAdminGetUserQueryKey(id) }
  });

  const updateUser = useAdminUpdateUser();

  const handleToggleRole = () => {
    if (!user) return;
    const newRole = user.role === 'admin' ? 'user' : 'admin';
    updateUser.mutate({ id, data: { role: newRole } }, {
      onSuccess: () => {
        toast.success(`Kullanıcı rolü güncellendi: ${newRole}`);
        queryClient.invalidateQueries({ queryKey: getAdminGetUserQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getAdminListUsersQueryKey() });
      },
      onError: () => toast.error("Rol güncellenirken hata oluştu.")
    });
  };

  const handleToggleActive = () => {
    if (!user) return;
    const newActive = !user.isActive;
    updateUser.mutate({ id, data: { isActive: newActive } }, {
      onSuccess: () => {
        toast.success(`Kullanıcı durumu güncellendi: ${newActive ? 'Aktif' : 'Pasif'}`);
        queryClient.invalidateQueries({ queryKey: getAdminGetUserQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getAdminListUsersQueryKey() });
      },
      onError: () => toast.error("Durum güncellenirken hata oluştu.")
    });
  };

  if (isLoading || !user) {
    return (
      <AppLayout requireAdmin>
        <div className="flex items-center justify-center py-24">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout requireAdmin>
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-display font-bold text-foreground">
                {user.name || 'İsimsiz Kullanıcı'}
              </h1>
              <Badge variant={user.role === 'admin' ? "destructive" : "secondary"}>
                {user.role}
              </Badge>
              {!user.isActive && <Badge variant="outline" className="text-red-500 border-red-500/20">Pasif</Badge>}
            </div>
            <p className="text-muted-foreground font-mono text-sm">
              ID: #{user.id} • Clerk: {user.clerkId}
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-card border-border/50">
            <CardHeader>
              <CardTitle>İletişim Bilgileri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-sm font-medium text-muted-foreground">E-posta</div>
                <div className="text-base">{user.email}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground">Telefon</div>
                <div className="text-base">{user.phone || 'Belirtilmedi'}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground">Kayıt Tarihi</div>
                <div className="text-base">{new Date(user.createdAt).toLocaleString('tr-TR')}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border/50">
            <CardHeader>
              <CardTitle>Yönetim İşlemleri</CardTitle>
              <CardDescription>Tehlikeli eylemler, dikkatli kullanın.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-border/50 rounded-xl">
                <div>
                  <h4 className="font-medium">Yetki Seviyesi</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    Kullanıcıyı sistem yöneticisi yapın veya yetkisini alın.
                  </p>
                </div>
                <Button 
                  variant={user.role === 'admin' ? "outline" : "destructive"} 
                  size="sm"
                  onClick={handleToggleRole}
                  disabled={updateUser.isPending}
                >
                  <ShieldAlert className="w-4 h-4 mr-2" />
                  {user.role === 'admin' ? 'Yetkiyi Al' : 'Admin Yap'}
                </Button>
              </div>

              <div className="flex items-center justify-between p-4 border border-border/50 rounded-xl">
                <div>
                  <h4 className="font-medium">Hesap Durumu</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    Kullanıcının sisteme erişimini durdurun.
                  </p>
                </div>
                <Button 
                  variant={user.isActive ? "outline" : "default"} 
                  size="sm"
                  onClick={handleToggleActive}
                  disabled={updateUser.isPending}
                  className={user.isActive ? "text-destructive hover:bg-destructive/10" : ""}
                >
                  {user.isActive ? <UserX className="w-4 h-4 mr-2" /> : <UserCheck className="w-4 h-4 mr-2" />}
                  {user.isActive ? 'Hesabı Askıya Al' : 'Hesabı Aktifleştir'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
