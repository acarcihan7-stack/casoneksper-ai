import { useRoute } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useGetAnalysis, getGetAnalysisQueryKey, useAdminUpdateAnalysis, useAdminCreateReport, getAdminListAnalysesQueryKey } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ExternalLink, Save, FileCheck2, Car } from "lucide-react";
import { statusMap, paymentStatusMap } from "@/lib/status-map";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const reportSchema = z.object({
  reportUrl: z.string().url("Geçerli bir URL giriniz."),
  summary: z.string().optional(),
  riskScore: z.coerce.number().min(0).max(100).optional(),
  findings: z.string().optional(),
});

export default function AdminAnalysisDetail() {
  const [, params] = useRoute("/admin/analyses/:id");
  const id = params?.id ? parseInt(params.id, 10) : 0;
  const queryClient = useQueryClient();

  const { data: analysis, isLoading } = useGetAnalysis(id, {
    query: { enabled: !!id, queryKey: getGetAnalysisQueryKey(id) }
  });

  const updateAnalysis = useAdminUpdateAnalysis();
  const createReport = useAdminCreateReport();

  const handleStatusChange = (newStatus: any) => {
    updateAnalysis.mutate({ id, data: { status: newStatus } }, {
      onSuccess: () => {
        toast.success("Analiz durumu güncellendi.");
        queryClient.invalidateQueries({ queryKey: getGetAnalysisQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getAdminListAnalysesQueryKey() });
      },
      onError: () => toast.error("Durum güncellenirken hata oluştu.")
    });
  };

  const handlePaymentStatusChange = (newStatus: any) => {
    updateAnalysis.mutate({ id, data: { paymentStatus: newStatus } }, {
      onSuccess: () => {
        toast.success("Ödeme durumu güncellendi.");
        queryClient.invalidateQueries({ queryKey: getGetAnalysisQueryKey(id) });
      },
      onError: () => toast.error("Durum güncellenirken hata oluştu.")
    });
  };

  const form = useForm<z.infer<typeof reportSchema>>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      reportUrl: "",
      summary: "",
      riskScore: 0,
      findings: "",
    }
  });

  const onReportSubmit = (values: z.infer<typeof reportSchema>) => {
    createReport.mutate({ id, data: values }, {
      onSuccess: () => {
        toast.success("Rapor başarıyla oluşturuldu.");
        queryClient.invalidateQueries({ queryKey: getGetAnalysisQueryKey(id) });
        form.reset();
      },
      onError: () => toast.error("Rapor oluşturulurken bir hata oluştu.")
    });
  };

  if (isLoading || !analysis) {
    return (
      <AppLayout requireAdmin>
        <div className="flex items-center justify-center py-24">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  const statusInfo = statusMap[analysis.status] || { label: analysis.status, colorClass: "bg-secondary text-secondary-foreground" };
  const payStatusInfo = analysis.paymentStatus ? paymentStatusMap[analysis.paymentStatus] : null;

  return (
    <AppLayout requireAdmin>
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-display font-bold text-foreground">
                Talep #{analysis.id}
              </h1>
              <Badge className={statusInfo.colorClass} variant="outline">
                {statusInfo.label}
              </Badge>
            </div>
            <p className="text-muted-foreground">
              {analysis.userName} ({analysis.userEmail}) tarafından talep edildi.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Car className="h-5 w-5"/> Araç Bilgileri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div><span className="text-muted-foreground text-sm">Marka/Model:</span> <p className="font-semibold">{analysis.vehicleBrand} {analysis.vehicleModel}</p></div>
                  <div><span className="text-muted-foreground text-sm">Yıl:</span> <p className="font-semibold">{analysis.vehicleYear}</p></div>
                  <div><span className="text-muted-foreground text-sm">Plaka:</span> <p className="font-mono uppercase">{analysis.plateNumber || '-'}</p></div>
                  <div><span className="text-muted-foreground text-sm">Paket:</span> <p className="font-semibold">{analysis.packageName}</p></div>
                  <div className="col-span-2">
                    <span className="text-muted-foreground text-sm">İlan Linki:</span> 
                    <p>
                      <a href={analysis.listingUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline inline-flex items-center gap-1 break-all">
                        {analysis.listingUrl} <ExternalLink className="h-3 w-3 shrink-0" />
                      </a>
                    </p>
                  </div>
                  {analysis.notes && (
                    <div className="col-span-2 mt-4 pt-4 border-t border-border/50">
                      <span className="text-muted-foreground text-sm">Kullanıcı Notu:</span>
                      <p className="mt-1 bg-muted/30 p-3 rounded border border-border/30 text-sm whitespace-pre-wrap">{analysis.notes}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><FileCheck2 className="h-5 w-5"/> Rapor Teslimi</CardTitle>
                <CardDescription>Müşteriye iletilecek PDF raporunu ve risk özetini girin. Rapor oluşturulduğunda analiz durumu otomatik 'Tamamlandı' olur.</CardDescription>
              </CardHeader>
              <CardContent>
                {analysis.reportId ? (
                  <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 p-4 rounded-lg flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold">Rapor Teslim Edildi</h4>
                      <p className="text-sm opacity-90">Bu analiz için rapor oluşturulmuş.</p>
                    </div>
                  </div>
                ) : (
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onReportSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="reportUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>PDF Rapor URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://storage.com/rapor.pdf" {...field} className="bg-background" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="riskScore"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Risk Skoru (0-100)</FormLabel>
                              <FormControl>
                                <Input type="number" {...field} className="bg-background" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <FormField
                        control={form.control}
                        name="summary"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Kısa Özet</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Örn: Araç genel olarak temiz..." {...field} className="bg-background" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="findings"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Önemli Bulgular</FormLabel>
                            <FormControl>
                              <Textarea placeholder="1. Sağ çamurluk boyalı&#10;2. Tramer 15.000 TL" {...field} className="bg-background min-h-[100px]" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="flex justify-end pt-2">
                        <Button type="submit" disabled={createReport.isPending}>
                          {createReport.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                          <Save className="h-4 w-4 mr-2" /> Raporu Yükle ve Tamamla
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle>Durum Yönetimi</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Analiz Durumu</label>
                  <Select value={analysis.status} onValueChange={handleStatusChange} disabled={updateAnalysis.isPending}>
                    <SelectTrigger className="bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Beklemede</SelectItem>
                      <SelectItem value="paid">Ödendi (İşleme Alınacak)</SelectItem>
                      <SelectItem value="processing">İşleniyor</SelectItem>
                      <SelectItem value="completed">Tamamlandı</SelectItem>
                      <SelectItem value="cancelled">İptal Edildi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Ödeme Durumu</label>
                  <Select value={analysis.paymentStatus || 'unpaid'} onValueChange={handlePaymentStatusChange} disabled={updateAnalysis.isPending}>
                    <SelectTrigger className="bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unpaid">Ödenmedi</SelectItem>
                      <SelectItem value="paid">Ödendi</SelectItem>
                      <SelectItem value="refunded">İade Edildi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
