import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, packagesTable } from "@workspace/db";
import { ListPackagesResponse } from "@workspace/api-zod";

const router: IRouter = Router();

// GET /packages
router.get("/packages", async (_req, res): Promise<void> => {
  const packages = await db
    .select()
    .from(packagesTable)
    .where(eq(packagesTable.isActive, true))
    .orderBy(packagesTable.sortOrder);

  res.json(ListPackagesResponse.parse(packages));
});

export default router;
