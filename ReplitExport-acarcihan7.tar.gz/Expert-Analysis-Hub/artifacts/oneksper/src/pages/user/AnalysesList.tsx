import { useState } from "react";
import { Link } from "wouter";
import { useListMyAnalyses, getListMyAnalysesQueryKey } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, Search, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { statusMap } from "@/lib/status-map";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AnalysesList() {
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [search, setSearch] = useState("");

  const { data: analyses, isLoading } = useListMyAnalyses({
    query: {
      queryKey: getListMyAnalysesQueryKey()
    }
  });

  const filteredAnalyses = analyses?.filter(a => {
    if (filterStatus !== "all" && a.status !== filterStatus) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        a.vehicleBrand.toLowerCase().includes(q) ||
        a.vehicleModel.toLowerCase().includes(q) ||
        a.listingUrl.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <AppLayout>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Analizlerim</h1>
          <p className="text-muted-foreground mt-1">Geçmiş ve devam eden analiz talepleriniz.</p>
        </div>
        <Link href="/analyses/new">
          <Button className="shrink-0 gap-2">
            <PlusCircle className="h-4 w-4" />
            Yeni Analiz
          </Button>
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Marka, model veya ilan linki ara..." 
            className="pl-9 bg-card border-border/50"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[180px] bg-card border-border/50">
            <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
            <SelectValue placeholder="Durum Filtresi" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tümü</SelectItem>
            <SelectItem value="pending">Beklemede</SelectItem>
            <SelectItem value="paid">Ödendi</SelectItem>
            <SelectItem value="processing">İşleniyor</SelectItem>
            <SelectItem value="completed">Tamamlandı</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1,2,3].map(i => (
            <Card key={i} className="animate-pulse bg-card border-border/50 h-24"></Card>
          ))}
        </div>
      ) : filteredAnalyses && filteredAnalyses.length > 0 ? (
        <div className="grid gap-4">
          {filteredAnalyses.map(analysis => {
            const statusInfo = statusMap[analysis.status] || { label: analysis.status, colorClass: "bg-secondary text-secondary-foreground" };
            return (
              <Link key={analysis.id} href={`/analyses/${analysis.id}`}>
                <Card className="bg-card border-border/50 hover:border-primary/50 transition-colors cursor-pointer group">
                  <CardContent className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-3">
                        <span className="font-semibold text-lg group-hover:text-primary transition-colors">
                          {analysis.vehicleBrand} {analysis.vehicleModel} ({analysis.vehicleYear})
                        </span>
                        {analysis.plateNumber && (
                          <span className="px-2 py-0.5 rounded text-xs font-mono border border-border text-muted-foreground uppercase">
                            {analysis.plateNumber}
                          </span>
                        )}
                      </div>
                      <span className="text-sm text-muted-foreground truncate max-w-md">
                        {analysis.listingUrl}
                      </span>
                      <span className="text-sm text-muted-foreground mt-1">
                        Paket: {analysis.packageName || "Bilinmiyor"}
                      </span>
                    </div>
                    <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between gap-2">
                      <Badge className={statusInfo.colorClass} variant="outline">
                        {statusInfo.label}
                      </Badge>
                      <span className="text-sm text-muted-foreground font-mono">
                        {new Date(analysis.createdAt).toLocaleDateString('tr-TR')}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground border border-dashed border-border/50 rounded-xl bg-card/50">
          Kriterlere uygun analiz bulunamadı.
        </div>
      )}
    </AppLayout>
  );
}
