import { ReactNode, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth, useClerk } from "@clerk/react";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Loader2, LayoutDashboard, FileText, PlusCircle, User as UserIcon, LogOut, ShieldAlert, Users, Package, FileCheck2, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface AppLayoutProps {
  children: ReactNode;
  requireAdmin?: boolean;
}

export default function AppLayout({ children, requireAdmin = false }: AppLayoutProps) {
  const { isSignedIn } = useAuth();
  const { signOut } = useClerk();
  const [location, setLocation] = useLocation();
  
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

  const { data: user, isLoading } = useGetMe({
    query: {
      enabled: !!isSignedIn,
      queryKey: getGetMeQueryKey()
    }
  });

  useEffect(() => {
    if (!isSignedIn) {
      setLocation("/sign-in");
    }
  }, [isSignedIn, setLocation]);

  useEffect(() => {
    if (!isLoading && user) {
      if (requireAdmin && user.role !== 'admin') {
        setLocation("/dashboard");
      }
    }
  }, [user, isLoading, requireAdmin, setLocation]);

  if (!isSignedIn || isLoading || (requireAdmin && user?.role !== 'admin')) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const isAdmin = user?.role === 'admin';

  const userNav = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Analizlerim", href: "/analyses", icon: FileText },
    { name: "Yeni Analiz", href: "/analyses/new", icon: PlusCircle },
    { name: "Profilim", href: "/profile", icon: UserIcon },
  ];

  const adminNav = [
    { name: "Admin Panel", href: "/admin", icon: ShieldAlert },
    { name: "Kullanıcılar", href: "/admin/users", icon: Users },
    { name: "Tüm Analizler", href: "/admin/analyses", icon: FileText },
    { name: "Raporlar", href: "/admin/reports", icon: FileCheck2 },
    { name: "Paketler", href: "/admin/packages", icon: Package },
  ];

  const navItems = location.startsWith("/admin") && isAdmin ? adminNav : userNav;

  const handleSignOut = () => {
    signOut({ redirectUrl: basePath || "/" });
  };

  const NavContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer mb-8 hover:opacity-80 transition-opacity">
            <img src={`${basePath || ""}/logo.svg`} alt="OnEksper AI" className="h-8 w-auto" />
          </div>
        </Link>
        <div className="space-y-1">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/admin" && item.href !== "/dashboard" && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div className={`flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-white/5 hover:text-foreground'}`}>
                  <item.icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
      
      <div className="mt-auto p-6 border-t border-border">
        {isAdmin && !location.startsWith("/admin") && (
          <Link href="/admin">
            <div className="flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer text-muted-foreground hover:bg-white/5 hover:text-foreground mb-2">
              <ShieldAlert className="h-5 w-5" />
              <span>Admin Panele Geç</span>
            </div>
          </Link>
        )}
        {isAdmin && location.startsWith("/admin") && (
          <Link href="/dashboard">
            <div className="flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer text-muted-foreground hover:bg-white/5 hover:text-foreground mb-2">
              <UserIcon className="h-5 w-5" />
              <span>Kullanıcı Görünümü</span>
            </div>
          </Link>
        )}
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer text-destructive hover:bg-destructive/10 transition-colors" onClick={handleSignOut}>
          <LogOut className="h-5 w-5" />
          <span>Çıkış Yap</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex w-full">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-border bg-card/50">
        <NavContent />
      </aside>

      {/* Mobile Header & Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden h-16 border-b border-border flex items-center px-4 justify-between bg-card/50">
          <Link href="/">
            <img src={`${basePath || ""}/logo.svg`} alt="OnEksper AI" className="h-6 w-auto" />
          </Link>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0 border-r-border bg-card">
              <NavContent />
            </SheetContent>
          </Sheet>
        </header>

        <main className="flex-1 overflow-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
