import { Router, type IRouter } from "express";
import { eq, count, sum } from "drizzle-orm";
import { db, usersTable, analysesTable, packagesTable, reportsTable } from "@workspace/db";
import { requireAuth, getOrCreateUser } from "../lib/auth";
import { GetDashboardSummaryResponse } from "@workspace/api-zod";
import { getAuth } from "@clerk/express";
import { desc } from "drizzle-orm";

const router: IRouter = Router();

// GET /dashboard/summary
router.get("/dashboard/summary", requireAuth, async (req, res): Promise<void> => {
  const clerkId = (req as any).clerkId as string;
  const auth = getAuth(req);
  const email = auth?.sessionClaims?.email as string ?? "";
  const user = await getOrCreateUser(clerkId, email);

  const [totalResult] = await db
    .select({ count: count() })
    .from(analysesTable)
    .where(eq(analysesTable.userId, user.id));

  const [pendingResult] = await db
    .select({ count: count() })
    .from(analysesTable)
    .where(eq(analysesTable.userId, user.id));

  const allAnalyses = await db
    .select({
      status: analysesTable.status,
      paymentStatus: analysesTable.paymentStatus,
      packageId: analysesTable.packageId,
    })
    .from(analysesTable)
    .where(eq(analysesTable.userId, user.id));

  const totalAnalyses = allAnalyses.length;
  const pendingAnalyses = allAnalyses.filter(a => a.status === "pending" || a.status === "processing").length;
  const completedAnalyses = allAnalyses.filter(a => a.status === "completed").length;

  // Get package prices for paid analyses
  const paidAnalysesPkgIds = allAnalyses
    .filter(a => a.paymentStatus === "paid")
    .map(a => a.packageId);

  let totalSpendKurus = 0;
  if (paidAnalysesPkgIds.length > 0) {
    const packages = await db.select().from(packagesTable);
    const pkgMap = new Map(packages.map(p => [p.id, p.priceKurus]));
    totalSpendKurus = paidAnalysesPkgIds.reduce((sum, id) => sum + (pkgMap.get(id) ?? 0), 0);
  }

  const recentAnalyses = await db
    .select({
      id: analysesTable.id,
      userId: analysesTable.userId,
      listingUrl: analysesTable.listingUrl,
      vehicleBrand: analysesTable.vehicleBrand,
      vehicleModel: analysesTable.vehicleModel,
      vehicleYear: analysesTable.vehicleYear,
      plateNumber: analysesTable.plateNumber,
      notes: analysesTable.notes,
      status: analysesTable.status,
      packageId: analysesTable.packageId,
      packageName: packagesTable.name,
      paymentStatus: analysesTable.paymentStatus,
      reportId: reportsTable.id,
      createdAt: analysesTable.createdAt,
      updatedAt: analysesTable.updatedAt,
      userEmail: usersTable.email,
      userName: usersTable.name,
    })
    .from(analysesTable)
    .leftJoin(packagesTable, eq(analysesTable.packageId, packagesTable.id))
    .leftJoin(reportsTable, eq(reportsTable.analysisId, analysesTable.id))
    .leftJoin(usersTable, eq(analysesTable.userId, usersTable.id))
    .where(eq(analysesTable.userId, user.id))
    .orderBy(desc(analysesTable.createdAt))
    .limit(5);

  res.json(GetDashboardSummaryResponse.parse({
    totalAnalyses,
    pendingAnalyses,
    completedAnalyses,
    totalSpendKurus,
    recentAnalyses,
  }));
});

export default router;
