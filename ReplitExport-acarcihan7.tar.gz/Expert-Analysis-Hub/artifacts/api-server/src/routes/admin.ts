import { Router, type IRouter } from "express";
import { eq, count, sum, desc } from "drizzle-orm";
import { db, usersTable, analysesTable, packagesTable, reportsTable } from "@workspace/db";
import { requireAdmin } from "../lib/auth";
import {
  GetAdminStatsResponse,
  AdminListUsersResponse,
  AdminGetUserResponse,
  AdminUpdateUserBody,
  AdminUpdateUserParams,
  AdminUpdateUserResponse,
  AdminListAnalysesResponse,
  AdminUpdateAnalysisBody,
  AdminUpdateAnalysisParams,
  AdminUpdateAnalysisResponse,
  AdminCreateReportBody,
  AdminCreateReportParams,
  AdminCreateReportResponse,
  AdminListReportsResponse,
  AdminCreatePackageBody,
  AdminCreatePackageResponse,
  AdminUpdatePackageBody,
  AdminUpdatePackageParams,
  AdminUpdatePackageResponse,
  AdminDeletePackageParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

// GET /admin/stats
router.get("/admin/stats", requireAdmin, async (req, res): Promise<void> => {
  const [userCount] = await db.select({ count: count() }).from(usersTable);
  const [analysisCount] = await db.select({ count: count() }).from(analysesTable);

  const allAnalyses = await db
    .select({
      status: analysesTable.status,
      paymentStatus: analysesTable.paymentStatus,
      packageId: analysesTable.packageId,
    })
    .from(analysesTable);

  const pendingAnalyses = allAnalyses.filter(a => a.status === "pending").length;
  const processingAnalyses = allAnalyses.filter(a => a.status === "processing").length;
  const completedAnalyses = allAnalyses.filter(a => a.status === "completed").length;

  const paidPkgIds = allAnalyses.filter(a => a.paymentStatus === "paid").map(a => a.packageId);
  let totalRevenue = 0;
  if (paidPkgIds.length > 0) {
    const packages = await db.select().from(packagesTable);
    const pkgMap = new Map(packages.map(p => [p.id, p.priceKurus]));
    totalRevenue = paidPkgIds.reduce((acc, id) => acc + (pkgMap.get(id) ?? 0), 0);
  }

  const recentAnalyses = await db
    .select({
      id: analysesTable.id,
      userId: analysesTable.userId,
      listingUrl: analysesTable.listingUrl,
      vehicleBrand: analysesTable.vehicleBrand,
      vehicleModel: analysesTable.vehicleModel,
      vehicleYear: analysesTable.vehicleYear,
      plateNumber: analysesTable.plateNumber,
      notes: analysesTable.notes,
      status: analysesTable.status,
      packageId: analysesTable.packageId,
      packageName: packagesTable.name,
      paymentStatus: analysesTable.paymentStatus,
      reportId: reportsTable.id,
      createdAt: analysesTable.createdAt,
      updatedAt: analysesTable.updatedAt,
      userEmail: usersTable.email,
      userName: usersTable.name,
    })
    .from(analysesTable)
    .leftJoin(packagesTable, eq(analysesTable.packageId, packagesTable.id))
    .leftJoin(reportsTable, eq(reportsTable.analysisId, analysesTable.id))
    .leftJoin(usersTable, eq(analysesTable.userId, usersTable.id))
    .orderBy(desc(analysesTable.createdAt))
    .limit(10);

  res.json(GetAdminStatsResponse.parse({
    totalUsers: Number(userCount?.count ?? 0),
    totalAnalyses: Number(analysisCount?.count ?? 0),
    totalRevenue,
    pendingAnalyses,
    completedAnalyses,
    processingAnalyses,
    recentAnalyses,
  }));
});

// GET /admin/users
router.get("/admin/users", requireAdmin, async (req, res): Promise<void> => {
  const page = parseInt(String(req.query.page ?? "1"), 10);
  const limit = parseInt(String(req.query.limit ?? "20"), 10);
  const offset = (page - 1) * limit;

  const [countResult] = await db.select({ count: count() }).from(usersTable);
  const users = await db
    .select()
    .from(usersTable)
    .orderBy(desc(usersTable.createdAt))
    .limit(limit)
    .offset(offset);

  // Get analysis counts per user
  const analysisCountsRaw = await db
    .select({ userId: analysesTable.userId, count: count() })
    .from(analysesTable)
    .groupBy(analysesTable.userId);
  const countMap = new Map(analysisCountsRaw.map(r => [r.userId, Number(r.count)]));

  const items = users.map(u => ({ ...u, analysisCount: countMap.get(u.id) ?? 0 }));

  res.json(AdminListUsersResponse.parse({
    items,
    total: Number(countResult?.count ?? 0),
    page,
    limit,
  }));
});

// GET /admin/users/:id
router.get("/admin/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const [countResult] = await db
    .select({ count: count() })
    .from(analysesTable)
    .where(eq(analysesTable.userId, user.id));

  res.json(AdminGetUserResponse.parse({ ...user, analysisCount: Number(countResult?.count ?? 0) }));
});

// PATCH /admin/users/:id
router.patch("/admin/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = AdminUpdateUserParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = AdminUpdateUserBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [updated] = await db
    .update(usersTable)
    .set(body.data)
    .where(eq(usersTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const [countResult] = await db
    .select({ count: count() })
    .from(analysesTable)
    .where(eq(analysesTable.userId, updated.id));

  res.json(AdminUpdateUserResponse.parse({ ...updated, analysisCount: Number(countResult?.count ?? 0) }));
});

// GET /admin/analyses
router.get("/admin/analyses", requireAdmin, async (req, res): Promise<void> => {
  const page = parseInt(String(req.query.page ?? "1"), 10);
  const limit = parseInt(String(req.query.limit ?? "20"), 10);
  const offset = (page - 1) * limit;
  const statusFilter = req.query.status as string | undefined;

  const [countResult] = await db.select({ count: count() }).from(analysesTable);

  let query = db
    .select({
      id: analysesTable.id,
      userId: analysesTable.userId,
      listingUrl: analysesTable.listingUrl,
      vehicleBrand: analysesTable.vehicleBrand,
      vehicleModel: analysesTable.vehicleModel,
      vehicleYear: analysesTable.vehicleYear,
      plateNumber: analysesTable.plateNumber,
      notes: analysesTable.notes,
      status: analysesTable.status,
      packageId: analysesTable.packageId,
      packageName: packagesTable.name,
      paymentStatus: analysesTable.paymentStatus,
      reportId: reportsTable.id,
      createdAt: analysesTable.createdAt,
      updatedAt: analysesTable.updatedAt,
      userEmail: usersTable.email,
      userName: usersTable.name,
    })
    .from(analysesTable)
    .leftJoin(packagesTable, eq(analysesTable.packageId, packagesTable.id))
    .leftJoin(reportsTable, eq(reportsTable.analysisId, analysesTable.id))
    .leftJoin(usersTable, eq(analysesTable.userId, usersTable.id))
    .orderBy(desc(analysesTable.createdAt))
    .limit(limit)
    .offset(offset);

  const analyses = statusFilter
    ? await query.where(eq(analysesTable.status, statusFilter))
    : await query;

  res.json(AdminListAnalysesResponse.parse({
    items: analyses,
    total: Number(countResult?.count ?? 0),
    page,
    limit,
  }));
});

// PATCH /admin/analyses/:id
router.patch("/admin/analyses/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = AdminUpdateAnalysisParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = AdminUpdateAnalysisBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [updated] = await db
    .update(analysesTable)
    .set(body.data)
    .where(eq(analysesTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Analysis not found" });
    return;
  }

  const [joined] = await db
    .select({
      id: analysesTable.id,
      userId: analysesTable.userId,
      listingUrl: analysesTable.listingUrl,
      vehicleBrand: analysesTable.vehicleBrand,
      vehicleModel: analysesTable.vehicleModel,
      vehicleYear: analysesTable.vehicleYear,
      plateNumber: analysesTable.plateNumber,
      notes: analysesTable.notes,
      status: analysesTable.status,
      packageId: analysesTable.packageId,
      packageName: packagesTable.name,
      paymentStatus: analysesTable.paymentStatus,
      reportId: reportsTable.id,
      createdAt: analysesTable.createdAt,
      updatedAt: analysesTable.updatedAt,
      userEmail: usersTable.email,
      userName: usersTable.name,
    })
    .from(analysesTable)
    .leftJoin(packagesTable, eq(analysesTable.packageId, packagesTable.id))
    .leftJoin(reportsTable, eq(reportsTable.analysisId, analysesTable.id))
    .leftJoin(usersTable, eq(analysesTable.userId, usersTable.id))
    .where(eq(analysesTable.id, params.data.id));

  res.json(AdminUpdateAnalysisResponse.parse(joined));
});

// POST /admin/analyses/:id/report
router.post("/admin/analyses/:id/report", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = AdminCreateReportParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = AdminCreateReportBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  // Check analysis exists
  const [analysis] = await db.select().from(analysesTable).where(eq(analysesTable.id, params.data.id));
  if (!analysis) {
    res.status(404).json({ error: "Analysis not found" });
    return;
  }

  // Upsert report
  const existing = await db.select().from(reportsTable).where(eq(reportsTable.analysisId, params.data.id));
  let report;
  if (existing.length) {
    [report] = await db
      .update(reportsTable)
      .set(body.data)
      .where(eq(reportsTable.analysisId, params.data.id))
      .returning();
  } else {
    [report] = await db
      .insert(reportsTable)
      .values({ analysisId: params.data.id, ...body.data })
      .returning();
  }

  // Mark analysis as completed
  await db
    .update(analysesTable)
    .set({ status: "completed" })
    .where(eq(analysesTable.id, params.data.id));

  res.status(201).json(AdminCreateReportResponse.parse(report));
});

// GET /admin/reports
router.get("/admin/reports", requireAdmin, async (req, res): Promise<void> => {
  const reports = await db
    .select()
    .from(reportsTable)
    .orderBy(desc(reportsTable.createdAt));

  res.json(AdminListReportsResponse.parse(reports));
});

// POST /admin/packages
router.post("/admin/packages", requireAdmin, async (req, res): Promise<void> => {
  const body = AdminCreatePackageBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [pkg] = await db.insert(packagesTable).values(body.data).returning();
  res.status(201).json(AdminCreatePackageResponse.parse(pkg));
});

// PUT /admin/packages/:id
router.put("/admin/packages/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = AdminUpdatePackageParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = AdminUpdatePackageBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [pkg] = await db
    .update(packagesTable)
    .set(body.data)
    .where(eq(packagesTable.id, params.data.id))
    .returning();

  if (!pkg) {
    res.status(404).json({ error: "Package not found" });
    return;
  }

  res.json(AdminUpdatePackageResponse.parse(pkg));
});

// DELETE /admin/packages/:id
router.delete("/admin/packages/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = AdminDeletePackageParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await db.delete(packagesTable).where(eq(packagesTable.id, params.data.id));
  res.sendStatus(204);
});

export default router;
