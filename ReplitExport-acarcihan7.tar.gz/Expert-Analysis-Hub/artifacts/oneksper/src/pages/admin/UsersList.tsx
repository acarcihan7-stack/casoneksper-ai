import { useState } from "react";
import { Link } from "wouter";
import { useAdminListUsers, getAdminListUsersQueryKey } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ChevronLeft, ChevronRight, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function AdminUsersList() {
  const [page, setPage] = useState(1);
  const limit = 10;
  
  const { data, isLoading, isPreviousData } = useAdminListUsers(
    { page, limit },
    { query: { keepPreviousData: true, queryKey: getAdminListUsersQueryKey({ page, limit }) } as any }
  );

  return (
    <AppLayout requireAdmin>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Kullanıcılar</h1>
          <p className="text-muted-foreground mt-1">Sistemdeki tüm üyeleri yönetin.</p>
        </div>
      </div>

      <div className="border border-border/50 rounded-xl overflow-hidden bg-card shadow-sm">
        <div className="p-4 border-b border-border/50 flex justify-between items-center bg-muted/20">
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Ara..." className="pl-9 h-9 bg-background" disabled />
          </div>
        </div>

        <div className="overflow-x-auto relative min-h-[400px]">
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center bg-card/50 z-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : null}
          
          <table className="w-full text-sm text-left">
            <thead className="bg-muted/50 text-muted-foreground uppercase text-xs">
              <tr>
                <th className="px-6 py-3 font-medium">ID</th>
                <th className="px-6 py-3 font-medium">Kullanıcı Bilgileri</th>
                <th className="px-6 py-3 font-medium">Rol</th>
                <th className="px-6 py-3 font-medium">Analiz Sayısı</th>
                <th className="px-6 py-3 font-medium">Kayıt Tarihi</th>
                <th className="px-6 py-3 font-medium text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className={isPreviousData ? "opacity-50" : ""}>
              {data?.items?.map((user) => (
                <tr key={user.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-muted-foreground">#{user.id}</td>
                  <td className="px-6 py-4">
                    <div className="font-medium text-foreground">{user.name || 'İsimsiz'}</div>
                    <div className="text-xs text-muted-foreground">{user.email}</div>
                    {user.phone && <div className="text-xs text-muted-foreground mt-0.5">{user.phone}</div>}
                  </td>
                  <td className="px-6 py-4">
                    <Badge variant={user.role === 'admin' ? "destructive" : "secondary"}>
                      {user.role}
                    </Badge>
                    {!user.isActive && <Badge variant="outline" className="ml-2 text-red-500 border-red-500/20">Pasif</Badge>}
                  </td>
                  <td className="px-6 py-4 font-mono">
                    {user.analysisCount || 0}
                  </td>
                  <td className="px-6 py-4 font-mono text-xs">
                    {new Date(user.createdAt).toLocaleDateString('tr-TR')}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <Link href={`/admin/users/${user.id}`}>
                      <Button variant="ghost" size="sm" className="h-8">İncele</Button>
                    </Link>
                  </td>
                </tr>
              ))}
              {(!data?.items || data.items.length === 0) && !isLoading && (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">Kullanıcı bulunamadı.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {data && data.total > 0 && (
          <div className="p-4 border-t border-border/50 flex items-center justify-between bg-muted/20">
            <span className="text-sm text-muted-foreground">
              Toplam <span className="font-medium text-foreground">{data.total}</span> kayıt
            </span>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1 || isLoading}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setPage(p => p + 1)}
                disabled={page * limit >= data.total || isLoading}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
