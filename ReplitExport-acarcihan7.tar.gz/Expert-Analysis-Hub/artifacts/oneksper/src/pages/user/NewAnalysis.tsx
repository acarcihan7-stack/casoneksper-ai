import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useCreateAnalysis, useListPackages, getListMyAnalysesQueryKey, getListPackagesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { ShieldCheck, Loader2 } from "lucide-react";
import { toast } from "sonner";

const analysisSchema = z.object({
  listingUrl: z.string().url({ message: "Geçerli bir ilan linki giriniz." }),
  vehicleBrand: z.string().min(2, { message: "Marka giriniz." }),
  vehicleModel: z.string().min(1, { message: "Model giriniz." }),
  vehicleYear: z.coerce.number().min(1900).max(new Date().getFullYear() + 1, { message: "Geçerli bir yıl giriniz." }),
  plateNumber: z.string().optional(),
  notes: z.string().optional(),
  packageId: z.coerce.number().min(1, { message: "Lütfen bir paket seçiniz." })
});

export default function NewAnalysis() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createAnalysis = useCreateAnalysis();
  
  const { data: packages, isLoading: loadingPackages } = useListPackages({
    query: { queryKey: getListPackagesQueryKey() }
  });

  const form = useForm<z.infer<typeof analysisSchema>>({
    resolver: zodResolver(analysisSchema),
    defaultValues: {
      listingUrl: "",
      vehicleBrand: "",
      vehicleModel: "",
      vehicleYear: new Date().getFullYear(),
      plateNumber: "",
      notes: "",
      packageId: 0,
    }
  });

  const onSubmit = (values: z.infer<typeof analysisSchema>) => {
    createAnalysis.mutate({ data: values }, {
      onSuccess: (data) => {
        toast.success("Analiz talebiniz oluşturuldu.");
        queryClient.invalidateQueries({ queryKey: getListMyAnalysesQueryKey() });
        setLocation(`/analyses/${data.id}`);
      },
      onError: () => {
        toast.error("Talep oluşturulurken bir hata oluştu.");
      }
    });
  };

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold text-foreground">Yeni Analiz</h1>
          <p className="text-muted-foreground mt-1">Sorgulamak istediğiniz aracın ilan linkini ve bilgilerini girin.</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle>İlan & Araç Bilgileri</CardTitle>
                <CardDescription>İlan URL'sini ve aracın temel bilgilerini girin.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="listingUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>İlan URL'si</FormLabel>
                      <FormControl>
                        <Input placeholder="https://..." {...field} className="bg-background" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="vehicleBrand"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Marka</FormLabel>
                        <FormControl>
                          <Input placeholder="Örn: BMW" {...field} className="bg-background" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="vehicleModel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model</FormLabel>
                        <FormControl>
                          <Input placeholder="Örn: 320i" {...field} className="bg-background" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="vehicleYear"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Yıl</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} className="bg-background" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="plateNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Plaka (İsteğe Bağlı)</FormLabel>
                        <FormControl>
                          <Input placeholder="Örn: 34ABC123" {...field} className="bg-background uppercase" />
                        </FormControl>
                        <FormDescription>Daha kapsamlı hasar kaydı sorgusu için önerilir.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ek Notlar (İsteğe Bağlı)</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Analizde özellikle dikkat edilmesini istediğiniz detaylar..." {...field} className="bg-background min-h-[100px]" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle>Paket Seçimi</CardTitle>
                <CardDescription>Size uygun raporlama detayını seçin.</CardDescription>
              </CardHeader>
              <CardContent>
                <FormField
                  control={form.control}
                  name="packageId"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        {loadingPackages ? (
                          <div className="flex justify-center p-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
                        ) : (
                          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {packages?.map(pkg => {
                              const isSelected = field.value === pkg.id;
                              return (
                                <div 
                                  key={pkg.id} 
                                  onClick={() => field.onChange(pkg.id)}
                                  className={`relative rounded-xl border p-4 cursor-pointer transition-all ${isSelected ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'border-border/50 bg-background hover:border-primary/50'}`}
                                >
                                  {pkg.isPopular && (
                                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-[10px] font-bold px-2 py-0.5 rounded-full">
                                      POPÜLER
                                    </div>
                                  )}
                                  <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-semibold">{pkg.name}</h4>
                                    <span className="font-mono text-primary font-bold">₺{(pkg.priceKurus/100).toLocaleString('tr-TR')}</span>
                                  </div>
                                  <p className="text-xs text-muted-foreground mb-4 line-clamp-2">{pkg.description}</p>
                                  <ul className="space-y-1.5">
                                    {pkg.features.slice(0, 3).map((f, i) => (
                                      <li key={i} className="text-xs flex items-start gap-1.5 text-muted-foreground">
                                        <ShieldCheck className="w-3.5 h-3.5 text-primary shrink-0" />
                                        <span className="leading-tight">{f}</span>
                                      </li>
                                    ))}
                                    {pkg.features.length > 3 && (
                                      <li className="text-xs text-muted-foreground italic pl-5">
                                        + {pkg.features.length - 3} özellik daha
                                      </li>
                                    )}
                                  </ul>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </FormControl>
                      <FormMessage className="mt-4" />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            <div className="flex justify-end gap-4">
              <Button type="button" variant="outline" onClick={() => setLocation("/analyses")}>İptal</Button>
              <Button type="submit" disabled={createAnalysis.isPending} className="px-8">
                {createAnalysis.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                Analiz Talebini Oluştur
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </AppLayout>
  );
}
