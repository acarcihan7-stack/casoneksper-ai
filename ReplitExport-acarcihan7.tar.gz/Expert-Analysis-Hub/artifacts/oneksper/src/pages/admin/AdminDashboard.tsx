import { Link } from "wouter";
import { useGetAdminStats, getGetAdminStatsQueryKey } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, FileText, CreditCard, Clock, Activity } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { statusMap } from "@/lib/status-map";

export default function AdminDashboard() {
  const { data: stats, isLoading } = useGetAdminStats({
    query: { queryKey: getGetAdminStatsQueryKey() }
  });

  return (
    <AppLayout requireAdmin>
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold text-foreground">Sistem Özeti</h1>
        <p className="text-muted-foreground mt-1">Platform geneli canlı istatistikler ve son aktiviteler.</p>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-6 mb-8">
          {[1,2,3,4,5,6].map(i => (
            <Card key={i} className="animate-pulse bg-card border-border/50 h-[100px]"></Card>
          ))}
        </div>
      ) : stats ? (
        <>
          <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-6 mb-8">
            <Card className="bg-card border-border/50 lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">Toplam Kullanıcı</CardTitle>
                <Users className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold font-mono">{stats.totalUsers}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50 lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">Toplam Ciro</CardTitle>
                <CreditCard className="h-4 w-4 text-emerald-500" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold font-mono">₺{(stats.totalRevenue / 100).toLocaleString('tr-TR')}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50 lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">Toplam Analiz</CardTitle>
                <Activity className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold font-mono">{stats.totalAnalyses}</div>
              </CardContent>
            </Card>
            
            <Card className="bg-card border-border/50 lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-1 space-y-0">
                <CardTitle className="text-xs font-medium text-muted-foreground">Bekleyen</CardTitle>
                <Clock className="h-3 w-3 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold font-mono">{stats.pendingAnalyses}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50 lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-1 space-y-0">
                <CardTitle className="text-xs font-medium text-muted-foreground">İşlenen</CardTitle>
                <Activity className="h-3 w-3 text-purple-500" />
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold font-mono">{stats.processingAnalyses}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50 lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-1 space-y-0">
                <CardTitle className="text-xs font-medium text-muted-foreground">Tamamlanan</CardTitle>
                <FileText className="h-3 w-3 text-emerald-500" />
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold font-mono">{stats.completedAnalyses}</div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-display font-semibold">Son Analiz Talepleri</h2>
              <Link href="/admin/analyses">
                <Button variant="outline" size="sm">Tümünü Gör</Button>
              </Link>
            </div>
            
            <div className="border border-border/50 rounded-xl overflow-hidden bg-card">
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-muted/50 text-muted-foreground uppercase">
                    <tr>
                      <th className="px-6 py-3 font-medium">ID</th>
                      <th className="px-6 py-3 font-medium">Kullanıcı</th>
                      <th className="px-6 py-3 font-medium">Araç</th>
                      <th className="px-6 py-3 font-medium">Tarih</th>
                      <th className="px-6 py-3 font-medium">Durum</th>
                      <th className="px-6 py-3 font-medium text-right">İşlem</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats.recentAnalyses?.map((analysis) => {
                      const statusInfo = statusMap[analysis.status] || { label: analysis.status, colorClass: "bg-secondary text-secondary-foreground" };
                      return (
                        <tr key={analysis.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors">
                          <td className="px-6 py-4 font-mono">#{analysis.id}</td>
                          <td className="px-6 py-4">
                            <div className="font-medium text-foreground">{analysis.userName || 'İsimsiz'}</div>
                            <div className="text-xs text-muted-foreground">{analysis.userEmail}</div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="font-medium">{analysis.vehicleBrand} {analysis.vehicleModel}</div>
                            <div className="text-xs text-muted-foreground">{analysis.vehicleYear}</div>
                          </td>
                          <td className="px-6 py-4 font-mono text-xs">
                            {new Date(analysis.createdAt).toLocaleDateString('tr-TR', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' })}
                          </td>
                          <td className="px-6 py-4">
                            <Badge className={statusInfo.colorClass} variant="outline">{statusInfo.label}</Badge>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <Link href={`/admin/analyses/${analysis.id}`}>
                              <Button variant="ghost" size="sm" className="h-8">Yönet</Button>
                            </Link>
                          </td>
                        </tr>
                      );
                    })}
                    {(!stats.recentAnalyses || stats.recentAnalyses.length === 0) && (
                      <tr>
                        <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">Kayıt bulunamadı.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      ) : null}
    </AppLayout>
  );
}
