import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import packagesRouter from "./packages";
import analysesRouter from "./analyses";
import dashboardRouter from "./dashboard";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(usersRouter);
router.use(packagesRouter);
router.use(analysesRouter);
router.use(dashboardRouter);
router.use(adminRouter);

export default router;
