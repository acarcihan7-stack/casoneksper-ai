import { useState } from "react";
import { Link } from "wouter";
import { useAdminListAnalyses, getAdminListAnalysesQueryKey } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ChevronLeft, ChevronRight, Filter } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { statusMap } from "@/lib/status-map";

export default function AdminAnalysesList() {
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState<string>("all");
  const limit = 15;
  
  const queryParams = { page, limit, ...(status !== 'all' ? { status } : {}) };

  const { data, isLoading, isPreviousData } = useAdminListAnalyses(
    queryParams,
    { query: { keepPreviousData: true, queryKey: getAdminListAnalysesQueryKey(queryParams) } as any }
  );

  return (
    <AppLayout requireAdmin>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Tüm Analizler</h1>
          <p className="text-muted-foreground mt-1">Sistemdeki tüm araç analiz talepleri.</p>
        </div>
      </div>

      <div className="border border-border/50 rounded-xl overflow-hidden bg-card shadow-sm">
        <div className="p-4 border-b border-border/50 flex justify-between items-center bg-muted/20">
          <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
            <SelectTrigger className="w-[180px] bg-background">
              <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
              <SelectValue placeholder="Durum Filtresi" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tümü</SelectItem>
              <SelectItem value="pending">Beklemede</SelectItem>
              <SelectItem value="paid">Ödendi (İşlem Bekliyor)</SelectItem>
              <SelectItem value="processing">İşleniyor</SelectItem>
              <SelectItem value="completed">Tamamlandı</SelectItem>
              <SelectItem value="cancelled">İptal</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="overflow-x-auto relative min-h-[400px]">
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center bg-card/50 z-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : null}
          
          <table className="w-full text-sm text-left">
            <thead className="bg-muted/50 text-muted-foreground uppercase text-xs">
              <tr>
                <th className="px-6 py-3 font-medium">ID</th>
                <th className="px-6 py-3 font-medium">Kullanıcı</th>
                <th className="px-6 py-3 font-medium">Araç</th>
                <th className="px-6 py-3 font-medium">Paket / Ödeme</th>
                <th className="px-6 py-3 font-medium">Durum</th>
                <th className="px-6 py-3 font-medium text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className={isPreviousData ? "opacity-50" : ""}>
              {data?.items?.map((analysis) => {
                const statusInfo = statusMap[analysis.status] || { label: analysis.status, colorClass: "bg-secondary text-secondary-foreground" };
                return (
                  <tr key={analysis.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors">
                    <td className="px-6 py-4 font-mono text-xs text-muted-foreground">#{analysis.id}</td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-foreground">{analysis.userName || 'İsimsiz'}</div>
                      <div className="text-xs text-muted-foreground">{analysis.userEmail}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium">{analysis.vehicleBrand} {analysis.vehicleModel}</div>
                      <div className="text-xs text-muted-foreground font-mono">{analysis.vehicleYear} • {analysis.plateNumber || 'Plaka Yok'}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium">{analysis.packageName}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{analysis.paymentStatus}</div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge className={statusInfo.colorClass} variant="outline">{statusInfo.label}</Badge>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Link href={`/admin/analyses/${analysis.id}`}>
                        <Button variant="ghost" size="sm" className="h-8">Yönet</Button>
                      </Link>
                    </td>
                  </tr>
                );
              })}
              {(!data?.items || data.items.length === 0) && !isLoading && (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">Analiz bulunamadı.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {data && data.total > 0 && (
          <div className="p-4 border-t border-border/50 flex items-center justify-between bg-muted/20">
            <span className="text-sm text-muted-foreground">
              Toplam <span className="font-medium text-foreground">{data.total}</span> kayıt
            </span>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1 || isLoading}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setPage(p => p + 1)}
                disabled={page * limit >= data.total || isLoading}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
