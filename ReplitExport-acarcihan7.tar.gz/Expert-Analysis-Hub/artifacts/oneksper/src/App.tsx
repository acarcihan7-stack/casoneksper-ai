import { useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Switch, Route, useLocation, Router as WouterRouter, Redirect } from 'wouter';
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

import LandingPage from "./pages/public/LandingPage";
import DashboardRedirect from "./pages/user/DashboardRedirect";
import UserDashboard from "./pages/user/Dashboard";
import AnalysesList from "./pages/user/AnalysesList";
import AnalysisDetail from "./pages/user/AnalysisDetail";
import NewAnalysis from "./pages/user/NewAnalysis";
import Profile from "./pages/user/Profile";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUsersList from "./pages/admin/UsersList";
import AdminUserDetail from "./pages/admin/UserDetail";
import AdminAnalysesList from "./pages/admin/AnalysesList";
import AdminAnalysisDetail from "./pages/admin/AnalysisDetail";
import AdminReportsList from "./pages/admin/ReportsList";
import AdminPackagesManager from "./pages/admin/PackagesManager";
import NotFound from "./pages/not-found";

const queryClient = new QueryClient();

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "hsl(217, 91%, 60%)",
    colorForeground: "hsl(210, 20%, 96%)",
    colorMutedForeground: "hsl(210, 15%, 60%)",
    colorDanger: "hsl(0, 84%, 60%)",
    colorBackground: "hsl(210, 23%, 7%)",
    colorInput: "hsl(210, 23%, 13%)",
    colorInputForeground: "hsl(210, 20%, 96%)",
    colorNeutral: "hsl(210, 23%, 13%)",
    fontFamily: "'Inter', sans-serif",
    borderRadius: "0.5rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[#0A0D12] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#1A202A] shadow-2xl",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-foreground font-display font-semibold",
    headerSubtitle: "text-muted-foreground",
    socialButtonsBlockButtonText: "text-foreground font-medium",
    formFieldLabel: "text-foreground font-medium",
    footerActionLink: "text-primary hover:text-primary/90 font-medium",
    footerActionText: "text-muted-foreground",
    dividerText: "text-muted-foreground",
    identityPreviewEditButton: "text-primary hover:text-primary/90",
    formFieldSuccessText: "text-emerald-500",
    alertText: "text-foreground",
    logoBox: "h-12 w-auto mb-6",
    logoImage: "h-full w-auto object-contain brightness-0 invert",
    socialButtonsBlockButton: "border-border hover:bg-white/5",
    formButtonPrimary: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-none font-medium",
    formFieldInput: "bg-background border-border text-foreground focus:border-primary focus:ring-1 focus:ring-primary placeholder:text-muted-foreground",
    footerAction: "",
    dividerLine: "bg-border",
    alert: "bg-destructive/10 border-destructive/20",
    otpCodeFieldInput: "bg-background border-border text-foreground focus:border-primary focus:ring-1 focus:ring-primary",
    formFieldRow: "",
    main: "",
  },
};

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <DashboardRedirect />
      </Show>
      <Show when="signed-out">
        <LandingPage />
      </Show>
    </>
  );
}

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
      <div className="relative z-10 w-full max-w-md">
        <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
      </div>
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
      <div className="relative z-10 w-full max-w-md">
        <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
      </div>
    </div>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Welcome back",
            subtitle: "Sign in to access your dashboard",
          },
        },
        signUp: {
          start: {
            title: "Start analyzing",
            subtitle: "Create an account to get started",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ClerkQueryClientCacheInvalidator />
          <Switch>
            <Route path="/" component={HomeRedirect} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            
            {/* User Routes */}
            <Route path="/dashboard" component={UserDashboard} />
            <Route path="/analyses" component={AnalysesList} />
            <Route path="/analyses/new" component={NewAnalysis} />
            <Route path="/analyses/:id" component={AnalysisDetail} />
            <Route path="/profile" component={Profile} />

            {/* Admin Routes */}
            <Route path="/admin" component={AdminDashboard} />
            <Route path="/admin/users" component={AdminUsersList} />
            <Route path="/admin/users/:id" component={AdminUserDetail} />
            <Route path="/admin/analyses" component={AdminAnalysesList} />
            <Route path="/admin/analyses/:id" component={AdminAnalysisDetail} />
            <Route path="/admin/reports" component={AdminReportsList} />
            <Route path="/admin/packages" component={AdminPackagesManager} />

            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
