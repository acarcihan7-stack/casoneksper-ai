import { Card, CardContent } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md mx-4 border-border/50 shadow-2xl bg-card">
        <CardContent className="pt-6 flex flex-col items-center text-center">
          <AlertCircle className="h-12 w-12 text-destructive mb-4" />
          <h1 className="text-2xl font-display font-bold text-foreground">
            404 Sayfa Bulunamadı
          </h1>
          <p className="mt-2 text-sm text-muted-foreground mb-6">
            Aradığınız sayfa taşınmış veya silinmiş olabilir.
          </p>
          <Link href="/">
            <Button variant="default">Ana Sayfaya Dön</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
