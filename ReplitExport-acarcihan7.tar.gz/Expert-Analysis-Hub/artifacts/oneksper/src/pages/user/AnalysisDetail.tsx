import { useRoute } from "wouter";
import { useGetAnalysis, getGetAnalysisQueryKey, useInitiatePayment, useGetMyReport } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ExternalLink, Download, CreditCard, Car, Calendar, Hash, FileText, CheckCircle2 } from "lucide-react";
import { statusMap, paymentStatusMap } from "@/lib/status-map";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export default function AnalysisDetail() {
  const [, params] = useRoute("/analyses/:id");
  const id = params?.id ? parseInt(params.id, 10) : 0;
  const queryClient = useQueryClient();

  const { data: analysis, isLoading } = useGetAnalysis(id, {
    query: {
      enabled: !!id,
      queryKey: getGetAnalysisQueryKey(id)
    }
  });

  const initiatePayment = useInitiatePayment();
  
  const handlePayment = () => {
    if (!analysis) return;
    initiatePayment.mutate({ id, data: { packageId: analysis.packageId } }, {
      onSuccess: (res) => {
        if (res.checkoutUrl) {
          window.location.href = res.checkoutUrl;
        } else {
          // If mock payment succeeds immediately
          toast.success("Ödeme başarılı. Analiz süreci başladı.");
          queryClient.invalidateQueries({ queryKey: getGetAnalysisQueryKey(id) });
        }
      },
      onError: () => {
        toast.error("Ödeme başlatılırken bir hata oluştu.");
      }
    });
  };

  const { refetch: fetchReport, isFetching: isFetchingReport } = useGetMyReport(id, {
    query: {
      enabled: false, // only fetch on click
    }
  });

  const handleDownloadReport = async () => {
    try {
      const { data } = await fetchReport();
      if (data && data.reportUrl) {
        window.open(data.reportUrl, "_blank");
      } else {
        toast.error("Rapor URL'si bulunamadı.");
      }
    } catch (e) {
      toast.error("Rapor alınırken bir hata oluştu.");
    }
  };

  if (isLoading || !analysis) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center py-24">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  const statusInfo = statusMap[analysis.status] || { label: analysis.status, colorClass: "bg-secondary text-secondary-foreground" };
  const payStatusInfo = analysis.paymentStatus ? paymentStatusMap[analysis.paymentStatus] : null;

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-display font-bold text-foreground">
                {analysis.vehicleBrand} {analysis.vehicleModel}
              </h1>
              <Badge className={statusInfo.colorClass} variant="outline">
                {statusInfo.label}
              </Badge>
            </div>
            <p className="text-muted-foreground font-mono text-sm">
              Talep ID: #{analysis.id.toString().padStart(6, '0')} • {new Date(analysis.createdAt).toLocaleDateString('tr-TR', { hour: '2-digit', minute:'2-digit' })}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {analysis.status === 'pending' && (
              <Button onClick={handlePayment} disabled={initiatePayment.isPending} className="gap-2">
                {initiatePayment.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
                Güvenli Ödeme Yap
              </Button>
            )}
            {analysis.status === 'completed' && (
              <Button onClick={handleDownloadReport} disabled={isFetchingReport} className="gap-2">
                {isFetchingReport ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                Raporu İndir
              </Button>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle>Araç Bilgileri</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-6">
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground flex items-center gap-2 mb-1">
                      <Car className="h-4 w-4" /> Marka / Model
                    </dt>
                    <dd className="text-base font-semibold">{analysis.vehicleBrand} {analysis.vehicleModel}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground flex items-center gap-2 mb-1">
                      <Calendar className="h-4 w-4" /> Model Yılı
                    </dt>
                    <dd className="text-base font-semibold">{analysis.vehicleYear}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground flex items-center gap-2 mb-1">
                      <Hash className="h-4 w-4" /> Plaka
                    </dt>
                    <dd className="text-base font-mono uppercase">{analysis.plateNumber || 'Belirtilmedi'}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-muted-foreground flex items-center gap-2 mb-1">
                      <ExternalLink className="h-4 w-4" /> İlan URL
                    </dt>
                    <dd className="text-base truncate">
                      <a href={analysis.listingUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline flex items-center gap-1">
                        İlana Git <ExternalLink className="h-3 w-3" />
                      </a>
                    </dd>
                  </div>
                </dl>
                {analysis.notes && (
                  <div className="mt-6 pt-6 border-t border-border/50">
                    <dt className="text-sm font-medium text-muted-foreground flex items-center gap-2 mb-2">
                      <FileText className="h-4 w-4" /> Ek Notlar
                    </dt>
                    <dd className="text-sm text-foreground bg-background p-4 rounded-lg border border-border/50 whitespace-pre-wrap">
                      {analysis.notes}
                    </dd>
                  </div>
                )}
              </CardContent>
            </Card>

            {analysis.status === 'completed' && analysis.reportId && (
              <Card className="bg-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-primary">
                    <CheckCircle2 className="h-5 w-5" /> Analiz Tamamlandı
                  </CardTitle>
                  <CardDescription className="text-foreground/80">
                    Uzman yapay zeka sistemimiz ilanı inceledi ve raporunuzu hazırladı. 
                    Tüm risk skorlarını ve detaylı bulguları görmek için raporu indirebilirsiniz.
                  </CardDescription>
                </CardHeader>
              </Card>
            )}
          </div>

          <div className="space-y-6">
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle>İşlem Özeti</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Paket</span>
                  <span className="font-medium">{analysis.packageName || 'Bilinmiyor'}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Ödeme Durumu</span>
                  <span className={`font-medium ${payStatusInfo?.colorClass || ''}`}>
                    {payStatusInfo?.label || 'Bilinmiyor'}
                  </span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Sistem Durumu</span>
                  <Badge className={statusInfo.colorClass} variant="outline">
                    {statusInfo.label}
                  </Badge>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-sm text-muted-foreground">Tarih</span>
                  <span className="font-mono text-sm">{new Date(analysis.createdAt).toLocaleDateString('tr-TR')}</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-card border-border/50">
              <CardHeader>
                <CardTitle>Süreç</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative border-l border-border/50 ml-3 space-y-6">
                  <div className="relative pl-6">
                    <span className="absolute -left-1.5 top-1.5 h-3 w-3 rounded-full bg-primary ring-4 ring-background"></span>
                    <h4 className="font-medium text-sm">Talep Alındı</h4>
                    <p className="text-xs text-muted-foreground">Sisteme kaydedildi.</p>
                  </div>
                  <div className="relative pl-6">
                    <span className={`absolute -left-1.5 top-1.5 h-3 w-3 rounded-full ring-4 ring-background ${analysis.paymentStatus !== 'unpaid' ? 'bg-primary' : 'bg-muted border border-border'}`}></span>
                    <h4 className={`font-medium text-sm ${analysis.paymentStatus !== 'unpaid' ? '' : 'text-muted-foreground'}`}>Ödeme Onayı</h4>
                    <p className="text-xs text-muted-foreground">
                      {analysis.paymentStatus !== 'unpaid' ? 'Ödeme başarıyla alındı.' : 'Ödeme bekleniyor.'}
                    </p>
                  </div>
                  <div className="relative pl-6">
                    <span className={`absolute -left-1.5 top-1.5 h-3 w-3 rounded-full ring-4 ring-background ${['processing', 'completed'].includes(analysis.status) ? 'bg-primary' : 'bg-muted border border-border'}`}></span>
                    <h4 className={`font-medium text-sm ${['processing', 'completed'].includes(analysis.status) ? '' : 'text-muted-foreground'}`}>YZ Analizi</h4>
                    <p className="text-xs text-muted-foreground">
                      {['processing', 'completed'].includes(analysis.status) ? 'Veriler işleniyor/işlendi.' : 'Ödeme sonrası başlayacak.'}
                    </p>
                  </div>
                  <div className="relative pl-6">
                    <span className={`absolute -left-1.5 top-1.5 h-3 w-3 rounded-full ring-4 ring-background ${analysis.status === 'completed' ? 'bg-primary' : 'bg-muted border border-border'}`}></span>
                    <h4 className={`font-medium text-sm ${analysis.status === 'completed' ? '' : 'text-muted-foreground'}`}>Rapor Hazır</h4>
                    <p className="text-xs text-muted-foreground">
                      {analysis.status === 'completed' ? 'PDF raporunuz indirilebilir.' : 'Analiz bekleniyor.'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
