import { Link } from "wouter";
import { useGetDashboardSummary, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, FileText, Clock, CheckCircle2, CreditCard } from "lucide-react";
import { Badge } from "@/components/ui/badge";

import { statusMap } from "@/lib/status-map";

export default function UserDashboard() {
  const { data: summary, isLoading } = useGetDashboardSummary({
    query: {
      queryKey: getGetDashboardSummaryQueryKey()
    }
  });

  return (
    <AppLayout>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Hoş Geldiniz</h1>
          <p className="text-muted-foreground mt-1">Araç analiz özetiniz ve son işlemleriniz.</p>
        </div>
        <Link href="/analyses/new">
          <Button className="shrink-0 gap-2">
            <PlusCircle className="h-4 w-4" />
            Yeni Analiz
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          {[1,2,3,4].map(i => (
            <Card key={i} className="animate-pulse bg-card border-border/50 h-[120px]"></Card>
          ))}
        </div>
      ) : summary ? (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
            <Card className="bg-card border-border/50 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">Toplam Analiz</CardTitle>
                <FileText className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-mono">{summary.totalAnalyses}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">Bekleyen / İşlenen</CardTitle>
                <Clock className="h-4 w-4 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-mono">{summary.pendingAnalyses}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">Tamamlanan</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-mono">{summary.completedAnalyses}</div>
              </CardContent>
            </Card>
            <Card className="bg-card border-border/50 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">Toplam Harcama</CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-mono">₺{(summary.totalSpendKurus / 100).toLocaleString('tr-TR')}</div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-display font-semibold">Son Analizler</h2>
            {summary.recentAnalyses && summary.recentAnalyses.length > 0 ? (
              <div className="grid gap-4">
                {summary.recentAnalyses.map(analysis => {
                  const statusInfo = statusMap[analysis.status] || { label: analysis.status, colorClass: "bg-secondary text-secondary-foreground" };
                  return (
                    <Link key={analysis.id} href={`/analyses/${analysis.id}`}>
                      <Card className="bg-card border-border/50 hover:border-primary/50 transition-colors cursor-pointer group">
                        <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div className="flex flex-col">
                            <span className="font-semibold text-lg group-hover:text-primary transition-colors">
                              {analysis.vehicleBrand} {analysis.vehicleModel} ({analysis.vehicleYear})
                            </span>
                            <span className="text-sm text-muted-foreground truncate max-w-md">
                              {analysis.listingUrl}
                            </span>
                          </div>
                          <div className="flex items-center gap-4">
                            <Badge className={statusInfo.colorClass} variant="outline">
                              {statusInfo.label}
                            </Badge>
                            <span className="text-sm text-muted-foreground font-mono">
                              {new Date(analysis.createdAt).toLocaleDateString('tr-TR')}
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <Card className="bg-card border-dashed border-border/50">
                <CardContent className="flex flex-col items-center justify-center p-12 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground/50 mb-4" />
                  <h3 className="text-lg font-medium mb-2">Henüz analiz bulunmuyor</h3>
                  <p className="text-muted-foreground mb-6">İlk araç analizinizi oluşturarak başlayın.</p>
                  <Link href="/analyses/new">
                    <Button>Yeni Analiz Oluştur</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        </>
      ) : null}
    </AppLayout>
  );
}
